var lib = require('./lib.js');

window.Philippines = lib;
