
var lib = require('./src/js/lib.js');

module.exports = lib;
